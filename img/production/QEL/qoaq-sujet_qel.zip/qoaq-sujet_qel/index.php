<?php
session_start();

//phpinfo();

//Application du routage. A laisser en dernier
require 'application/core/main.php';
?>
