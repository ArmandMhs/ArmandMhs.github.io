<?php
require_once 'application/models/question.php';
require_once 'application/models/questionnaire.php';

creer_reponse($idQuestion,$position,$repOuverte);

//header('Location:'.$_SERVER['HTTP_REFERER'])
?>

