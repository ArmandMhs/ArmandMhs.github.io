<?php
require_once 'application/models/question.php';
require_once 'application/models/questionnaire.php';
//var_dump($_POST);

$idQuestionnaire = get_idquestionnaire_by_token($token);

creer_question_reponse($idQuestionnaire,$question,$reponses);

header('Location:'.$_SERVER['HTTP_REFERER']);

?>