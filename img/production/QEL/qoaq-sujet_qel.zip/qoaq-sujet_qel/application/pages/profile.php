<?php
require_once 'application/models/user.php';
require_once 'application/models/questionnaire.php';

$resultAdmin = get_all_questionnaire_admin($_SESSION['idUtilisateur']);
$resultUser = get_all_questionnaire_user($_SESSION['idUtilisateur']);


echo $blade->run('profile',compact('resultAdmin','resultUser'));
?>