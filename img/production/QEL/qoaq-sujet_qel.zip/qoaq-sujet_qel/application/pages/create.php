<?php

require_once 'application/models/question.php';
require_once 'application/models/questionnaire.php';

if (!isset($titre)){ // Si les paramètres ne sont pas présents ->  formulaire
  echo $blade->run('create');
  exit();
}

///////////// Construction du questionnaire
$tokenAdmin = generate_token(20);
$tokenUser = generate_token(20);
$idQuestionnaire = creer_questionnaire(compact('tokenAdmin','tokenUser','titre','fin','affichage'));

if (isset($_SESSION['idUtilisateur'])) {
  set_owner($_SESSION['idUtilisateur'], $idQuestionnaire);
}

//////////// Construction de la question
if ($ouverte == 'true') {
  $b_ouverte = true;
  creer_question_reponse($idQuestionnaire,$question,$reponses,$b_ouverte);

} else {
  creer_question_reponse($idQuestionnaire,$question,$reponses);
}


//var_dump($_POST);
// redirection sur la page admin du questionnaire
header('Location: '.get_admin_url($tokenAdmin));
?>
