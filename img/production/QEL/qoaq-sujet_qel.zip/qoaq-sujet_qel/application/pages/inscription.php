<?php
echo $blade->run('inscription');
?>