<?php 
echo $blade->run('legal');
?>