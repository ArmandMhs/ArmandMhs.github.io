<?php
if (isset($_SESSION['idUtilisateur']) && (isset($_SESSION['nom']))) {
    session_destroy();
    //var_dump($_SESSION);
    header("Location:".URL_INDEX);
}
?>