<?php

echo $blade->run('connexion');

?>