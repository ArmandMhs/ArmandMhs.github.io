<?php

require_once 'application/models/user.php';

if (isset($nom) && isset($email) && isset($password)){
    $register = register($nom, $email, $password);
    if ($register == true) {        //email déjà utilsé
        $error = "L'adresse mail que vous avez saisi est déjà utilisée. Veuillez en utilisez une autre";
        echo $blade->run('inscription', compact('error'));
    } else {
        header('Location:'.URL_INDEX."?page=connexion");
    }
}
?>