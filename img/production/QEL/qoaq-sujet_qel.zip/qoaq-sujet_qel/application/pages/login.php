<?php

require_once 'application/models/user.php';

if (isset($nom) && isset($email) && isset($password)) {
    $result = log_in($nom,$email,$password);
    //echo var_dump($result);
    if (is_array($result) ) {
        //echo "test pass";
        $_SESSION['idUtilisateur'] = $result['id'];
        $_SESSION['nom'] = $result['nom'];
        header("Location:".URL_INDEX);
    } else {
        $error = $result;
        //echo $error;
        echo $blade->run('connexion',compact('error'));
    }
}
?>