<?php
require_once 'application/models/question.php';
require_once 'application/models/questionnaire.php';

set_statut($_GET['id'], 'publie');

header('Location:'. $_SERVER['HTTP_REFERER']);

?>