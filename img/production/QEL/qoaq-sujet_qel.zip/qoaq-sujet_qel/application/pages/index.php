<?php
echo $blade->run('index');
?>
