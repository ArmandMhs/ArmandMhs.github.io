<?php
require_once 'application/core/routing.php';

// Configuration des routes, c'est à dire l'association entre les pages demandées
// et le code php à exécuter

// Le premier paramètre indique le fichier php à exécuter. Par exemple,
// index correspond à pages/index.php


// Les paramètres suivants indiquent les éventuels valeurs attendues et si il s'agit de GET ou POST
// Le fichier php correspondant n'est lancé que si tous les paramètres
// existent. Les paramètres validés sont automatiquement convertis
// en variables php de même nom

add_route('index'); // route par défaut

add_route('create'); // Création d'un nouvel évènement : formulaire
add_route('create',['titre','fin','question','reponses','affichage','ouverte'],'POST'); // creation proprement dite

add_route('admin',['token'],'GET'); // Affichage du questionnaire, coté administrateur

add_route('questionnaire',['token'],'GET'); // Création d'une participation

add_route('participation',['token'],'GET'); // Affichage de la participation

add_route('choix',['token', 'idReponse'],'GET'); // choix d'une réponse

add_route('legal');

add_route('publie', [], 'POST');

add_route('ajout', ['token','question','reponses'], 'POST');

add_route('connexion');

add_route('login', ['nom','email','password'], 'POST');

add_route('inscription');

add_route('register', ['nom','email','password'], 'POST');

add_route('logout');

add_route('profile');

add_route('ajoutReponse', ['position','idQuestion','repOuverte'], 'POST');
?>
