@extends('templates.main')

@section('content')
<h2> Inscription </h2>
<form action='{{URL_INDEX}}?page=register' method='post'>
<label for="nom"> Nom :
    <input type="text" id='idName' name='nom'>
</label>
<label for="email"> Email : 
    <input type="email" id='idEmail' name='email'>
</label>
<label for="password"> Mot de passe : 
    <input type="password" id='idPassword' name='password'>
</label>

<input type="submit" value='Se connecter'>
</form>

@if (isset($error))
    <p>{{$error}}</p>
@endif
@endsection