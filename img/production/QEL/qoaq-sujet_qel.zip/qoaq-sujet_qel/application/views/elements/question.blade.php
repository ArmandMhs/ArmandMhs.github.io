<div class="question">
  <h3>{{$question['question']}}</h3>
  <ul>
    @foreach($question['reponses'] as $reponse)
    <li>
      @if ($questionnaire['statut'] != 'termine')
      <a href="{!!get_url_choix($reponse,$participation)!!}">
      @endif


      @if($reponse['choix'])
      <div class="ok">{!!make_icon('check','','icon-ok')!!}</div>
      @endif
      @if ($questionnaire['affichage'] == 'toujours') <!-- Affichage du pourcentage : Toujours !-->
        @php($pourcent = $question['total']==0 ? 0 : ((int)((100*$reponse['count'])/
          $question['total'])))
          <div class="pourcent" style="width:{{$pourcent}}%"></div>
          {{$reponse['reponse']}}</a>
          <p>{{$pourcent}}%</p>
      @endif

      @if ($questionnaire['affichage'] == 'termine') <!-- Affichage du pourcentage : Termine !-->
        @if ($questionnaire['statut'] == 'termine')
        @php($pourcent = $question['total']==0 ? 0 : ((int)((100*$reponse['count'])/
          $question['total'])))
          <div class="pourcent" style="width:{{$pourcent}}%"></div>
        @endif
        @if ($questionnaire['statut'] != 'termine')
          {{$reponse['reponse']}}</a>
        @endif
        
        @if ($questionnaire['statut'] == 'termine')
        <p style="color:black;">{{$reponse['reponse']}}</p>
        @endif
        @if($questionnaire['statut'] == 'termine')
          <p style="color:black;">{{$pourcent}}%</p>
        @endif
      @endif

      @if ($questionnaire['affichage'] == 'apres') <!-- Affichage du pourcentage : Après !-->
      @if ($reponse['choix'])
        @php($pourcent = $question['total']==0 ? 0 : ((int)((100*$reponse['count'])/
          $question['total'])))
          <div class="pourcent" style="width:{{$pourcent}}%"></div>
      @endif
          {{$reponse['reponse']}}</a>
        @if($reponse['choix'])
          <p>{{$pourcent}}%</p>
        @endif
      @endif  
    </li>
    @endforeach
    @if($question["ouverte"]==1)
      <form action="index.php?page=ajoutReponse" method="POST">
        <label for="idRepOuverte">Autre réponse</label>
        <textarea id="idRepOuverte" name="repOuverte"></textarea>
        <input type="hidden" name="idQuestion" value="<?php echo $question["idQuestion"]; ?>">
        <input type="hidden" name="position" value="<?php echo COUNT($question["reponses"]) + 1;?>">
        <input type="submit">
      </form>
    @endif
  </ul>

</div>
