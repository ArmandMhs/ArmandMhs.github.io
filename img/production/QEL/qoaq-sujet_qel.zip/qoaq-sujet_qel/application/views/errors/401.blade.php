@extends('templates.main')
@section('content')
  <h2>401 Authentification requise</h2>
    <h3>Connectez-vous pour accéder à cette page</h3>
@endsection
