@extends('templates.main')

@section('content')
<h2>Administration du questionnaire</h2>
<h3>{!!make_icon('pencil')!!}{{$questionnaire['titre']}}</h3>
<h3>{!!make_icon('calendar')!!} Clôture à {{format_date($questionnaire['fin'])}}</h3>

<h2>Questions : </h2>
<ul>
@foreach($questions as $question)
  <li>{{$question['question']}}</li>
@endforeach
</ul>


<!-- Ajout de question!-->
@if($questionnaire['statut']=="creation")
<h2>Ajouter une question</h2>
<form action="{{URL_INDEX}}?page=ajout" method="post">
<input type="hidden" value="{{$_GET['token']}}" name=token  >
<fieldset>
<legend>Nouvelle question</legend >
@include("elements.question_form")
</fieldset>
<h2><input type="submit" value="Ajouter une question"></h2>
</form>
@endif

<h3>{!!make_icon('info-square')!!} Lien vers cette page (pour vous) <br>
      <code>{!!$questionnaire['adminUrl']!!}</code>
</h3>

<!-- Gestion du statut !-->
@if($questionnaire['statut']=="publie" || $questionnaire['statut']=='termine')
<h3>{!!make_icon('link','Lien à partager')!!}  <br>
<code>{!!$questionnaire['userUrl']!!}</code></h3>
@endif
@if($questionnaire['statut']=="creation")
  <form action="{{URL_INDEX}}?page=publie&id={{$questionnaire['id']}}" method='post'><label for="statut">Statut :</label>
    <input type="submit" value='publie'/>
  </form>
@endif

@endsection

@section('cta')

@endsection
