@extends('templates.main')
@section('content')
<h2>Hello world<h2>
@endsection