@extends('templates.main')
@section('content')
    @if ($resultAdmin != NULL)
    <h1>Questionnaire créé</h1>
    @foreach ($resultAdmin as $questionnaire)
        <?php
            $lienAdmin = get_admin_url($questionnaire['tokenAdmin']);
            $lienUser = get_user_url($questionnaire['tokenUser']);
        ?>
        @if ($questionnaire['statut']== 'creation')
            <div class=question>
                <p>Titre : <a href='{{$lienAdmin}}'>{{$questionnaire['titre']}}</a></p>
                <p>Statut : {{$questionnaire['statut']}}
            </div>
        @endif
        @if ($questionnaire['statut']== 'publie' or $questionnaire['statut'] == 'termine')
            <div class=question>
                <p>Titre : <a href='{{$lienUser}}'>{{$questionnaire['titre']}}</a></p>
                <p>Statut : {{$questionnaire['statut']}}
            </div>
        @endif
    @endforeach
    @endif

    @if ($resultUser != NULL)

    <h1>Questionnaire répondu</h1>
    @foreach ($resultUser as $questionnaire)
        <?php $lienUser = get_user_url($questionnaire['tokenUser']); ?>
        <div class=question>
            <p>Titre : <a href='{{$lienUser}}'>{{$questionnaire['titre']}}</a></p>
            <p>Statut : {{$questionnaire['statut']}}
        </div>

    @endforeach
    @endif

    @if ($resultUser == NULL AND $resultAdmin == NULL)
        <p>Pas de participation a un questionnaire. Vous pouvez en créé un <a href ='bit.ly/ardman2023'>ici</a></p>
    @endif
@endsection
