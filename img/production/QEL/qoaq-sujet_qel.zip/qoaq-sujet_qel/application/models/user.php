<?php
require_once 'application/core/database.php';

/*
Esssaie de connecter l'utilisateur
- Si email/password correspondent, la connexion est ok
- Sinon, si le compte existe c'est une erreur
- Sinon, on créé le compte
Paramètres :
  $nom
  $email
  $password
Retour :
  en cas d'échec : NULL (+ info dans la session)
  en cas de réussite : un tableau associatif avec les clefs id, email et nom
*/
function log_in($nom, $email, $password){
  global $pdo;     // Vérification du login/mot de passe
  $sql = "SELECT * FROM utilisateur WHERE nom = ? AND email = ? AND password = ?";
  $query = $pdo->prepare($sql);
  $query->execute(array($nom, $email, $password));
  $result = $query->fetch();
  if($result == true){
    return $result;
  } else {
    $sql = "SELECT * FROM utilisateur WHERE nom = ? OR email = ? OR password = ?";
    $query = $pdo->prepare($sql);
    $query->execute(array($nom, $email, $password));
    $result = $query->fetch();
    if ($result == true) {
      $error = "L'une des informations saisie est incorrect, veuillez réessayer.";
      return $error;
    } else {
      $error = "Le compte demandé n'existe pas inscrivez vous avec le bouton juste en dessous";
      return $error;
    }
  }
}
 
function register($nom, $email, $password){       //TODO
  global $pdo;
  $sql = "SELECT email FROM utilisateur WHERE email = ?"; //Vérification si l'adresse mail est déjà dans la base
  $query = $pdo->prepare($sql);
  $query->execute([$email]);
  $same = $query->fetch();
  if ($same == true) {
    return TRUE;
  } else {
    $sql = "INSERT INTO utilisateur(nom,email,password) VALUES (? , ? ,?)";
    $query = $pdo->prepare($sql);
    $query -> execute([$nom,$email,$password]); 
    return FALSE;
  }
}




/*
Cherche les questionnaires créés par un utilisateur
Paramètre :
  $idUtilisateur
Retour :
  Un tableau contenant les questionnaires (sous forme de tableaux assoicatifs)
  On fournit pour chaque questionnaire :
    - ses informations de base
    - url : le lien vers la page d'administration correspondante
*/
function get_all_questionnaire_admin($idUtilisateur){
  global $pdo;
  $sql = 'SELECT * FROM questionnaire WHERE idUtilisateur = ? ORDER BY debut DESC';
  $query = $pdo->prepare($sql);
  $query -> execute([$idUtilisateur]);
  while ($line = $query -> fetch()){
    $result[]=$line;
  }
  if(isset($result)){
    return $result;
  } else {
    return NULL;
  }
}

/*
Cherche les questionnaires auxquel un utilisateur a répondu
Paramètre :
  $idUtilisateur
Retour :
  Un tableau contenant les questionnaires (sous forme de tableaux assoicatifs)
  On fournit pour chaque questionnaire :
    - ses informations de base
    - url : le lien vers la participation correspondante
*/
function get_all_questionnaire_user($idUtilisateur){
  global $pdo;
  $sql = 'SELECT questionnaire.* 
  FROM questionnaire 
  JOIN participation ON participation.idQuestionnaire = questionnaire.id
  WHERE participation.idUtilisateur = ?';
  $query = $pdo->prepare($sql);
  $query -> execute([$idUtilisateur]);
  while ($line = $query -> fetch()){
    $result[]=$line;
  }
  if(isset($result)){
    return $result;
  } else {
    return NULL;
  }
}



?>
